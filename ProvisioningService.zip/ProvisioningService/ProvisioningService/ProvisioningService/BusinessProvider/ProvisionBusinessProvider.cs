﻿using System;
using ProvisioningService.Models;
using System.Data.SqlClient;
using System.Data;
using AzureTAble = Microsoft.WindowsAzure.Storage.Table;
using Newtonsoft.Json;
using Microsoft.WindowsAzure.Storage;
using System.Threading.Tasks;
using Microsoft.Azure;

namespace ProvisioningService.BusinessProvider
{
    public class ProvisionBusinessProvider
    {
        public static string provisionConnectionString = @"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Datasource\SimulatorDatabase.mdf;Integrated Security = True";       
        SqlCommand command;
        SqlConnection connection;
        SqlDataAdapter dataAdapter;
        DataTable dataTable;
        //public Provision GetProvisionDetails(string macId)
        //{
        //    Provision provision = new Provision();
        //    connection = new SqlConnection();
        //    connection.ConnectionString = provisionConnectionString;
        //    command = new SqlCommand("SELECT * FROM PROVISION WHERE macId='" + macId + "'", connection);
        //    command.CommandType = CommandType.Text;
        //    try
        //    {
        //        connection.Open();
        //        dataAdapter = new SqlDataAdapter();
        //        dataAdapter.SelectCommand = command;
        //        DataSet dataSet = new DataSet();
        //        dataAdapter.Fill(dataSet);
        //        if (dataSet.Tables.Count > 0)
        //        {
        //            if (dataSet.Tables[0].Rows.Count > 0)
        //            {
        //                provision.macId = (string)dataSet.Tables[0].Rows[0]["macId"];
        //                provision.secretKey = (string)dataSet.Tables[0].Rows[0]["secretKey"];
        //                provision.ioTHubEP = (string)dataSet.Tables[0].Rows[0]["IoTHubEP"];
        //                provision.authKey = (string)dataSet.Tables[0].Rows[0]["AuthKey"];
        //                provision.id = (int)dataSet.Tables[0].Rows[0]["SNo"];
        //            }
        //        }
        //        command.ExecuteNonQuery();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        connection.Close();
        //    }
        //    return provision;
        //}
        public Provision GetProvisionDetails(string deviceId, string secretKey)
        {
            try
            {
                AzureTAble.TableEntity result = RetrieveDataFromAzureTable("Provision", Convert.ToString(secretKey), Convert.ToString(deviceId));
                var serializedParent = JsonConvert.SerializeObject(result);
                ProvisionEntity provisionEntity = JsonConvert.DeserializeObject<ProvisionEntity>(serializedParent);
                Provision provisionObject = new Provision();
                if (result != null)
                {
                    provisionObject = new Provision
                    {
                        deviceId = provisionEntity.RowKey,
                        iotHubHostName = provisionEntity.iotHubHostName,
                        iotHubSuffix = provisionEntity.iotHubSuffix,
                        authKey = provisionEntity.authKey,
                        status = "Data"
                    };
                }
                else
                {
                    provisionObject = new Provision
                    {
                        deviceId = string.Empty,
                        iotHubHostName = string.Empty,
                        iotHubSuffix = string.Empty,
                        authKey = string.Empty,
                        status = "NoData"
                    };
                }
                return provisionObject;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
        
        public Microsoft.WindowsAzure.Storage.Table.TableEntity RetrieveDataFromAzureTable(string TableName, string PartitionKeyParam, string RowKeyParam)
        {
            try
            {
                // Table Name from Input String 
                AzureTAble.CloudTable SearchTable = CreateTableAsync(TableName).Result;

                // Retrieve Data from Table based on PKey andd RKey 
                AzureTAble.TableEntity ResultEntity = RetrieveEntityUsingPointQueryAsync(SearchTable, PartitionKeyParam, RowKeyParam).Result;

                // Return Data as Table Entity

                return ResultEntity;
            }
            catch (Exception ex)
            {
                throw new System.Exception(ex.Message.ToString());
            }
        }

        public static CloudStorageAccount CreateStorageAccountFromConnectionString(string storageConnectionString)
        {
            CloudStorageAccount storageAccount;
            try
            {
                storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            }
            catch (FormatException)
            {                
                throw;
            }
            catch (ArgumentException)
            {
                ////Console.WriteLine("Invalid storage account information provided. Please confirm the AccountName and AccountKey are valid in the app.config file - then restart the sample.");
                ////Console.ReadLine();
                throw;
            }

            return storageAccount;
        }

        public static async Task<AzureTAble.CloudTable> CreateTableAsync(string TableName)
        {
            // Retrieve storage account information from connection string.
            CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            // Create a table client for interacting with the table service
            AzureTAble.CloudTableClient tableClient = storageAccount.CreateCloudTableClient();                        
            // Create a table client for interacting with the table service 
            AzureTAble.CloudTable table = tableClient.GetTableReference(TableName);
            try
            {                
            }
            catch (StorageException)
            {             
                throw;
            }
            return table;
        }

        public static async Task<Microsoft.WindowsAzure.Storage.Table.TableEntity> RetrieveEntityUsingPointQueryAsync(AzureTAble.CloudTable table, string partitionKey, string rowKey)
        {
            AzureTAble.TableOperation retrieveOperation = null;
            Microsoft.WindowsAzure.Storage.Table.TableEntity resultEntity = null;
            switch (table.Name)
            {
                case "Provision":
                    retrieveOperation = AzureTAble.TableOperation.Retrieve<ProvisionEntity>(rowkey: rowKey, partitionKey: partitionKey);
                    AzureTAble.TableResult result = table.ExecuteAsync(retrieveOperation).Result;
                    resultEntity = result.Result as ProvisionEntity;
                    break;               
            }
            return resultEntity;
        }
    }
}