﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProvisioningService.Models
{
    using Microsoft.WindowsAzure.Storage.Table;
    public class ProvisionEntity : TableEntity
    {
        public ProvisionEntity() { }
        public ProvisionEntity(string deviceId, string secretKey)
        {            
            this.PartitionKey = secretKey;
            this.RowKey = deviceId;
        }
        public string iotHubHostName { get; set; }
        public string iotHubSuffix { get; set; }       
        public string authKey { get; set; }     
    }
}