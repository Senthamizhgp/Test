﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProvisioningService.Models
{
    public class Provision
    {
        public string deviceId { get; set; }
        //public string secretKey { get; set; }
        public string iotHubHostName { get; set; }
        public string iotHubSuffix { get; set; }
        public string authKey { get; set; }
        public string status { get; set; }
    }
    public class CommunicationDevice
    {       
        public string deviceId { get; set; }       
        public string secretKey { get; set; }
    }
}