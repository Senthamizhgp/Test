﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ProvisioningService.Models;
using ProvisioningService.BusinessProvider;
using System.Data;
using Newtonsoft.Json;
using System.Text;

namespace ProvisioningService.Controllers
{
    public class ProvisioningController : ApiController
    {        
        ProvisionBusinessProvider provisionBusinessProvider = new ProvisionBusinessProvider();
        [HttpGet]
        public Provision GetProvisionDetails(string deviceId, string secretKey)
        {
            try
            {
                return provisionBusinessProvider.GetProvisionDetails(deviceId, secretKey);
            }
            catch(Exception ex)
            {
                throw new System.Exception(ex.Message.ToString());
            }
        }                
        [HttpPost]
        public Provision GetProvisionDetailsPost([FromBody] CommunicationDevice deviceParameters)
        {
            try
            {
                string deviceId = deviceParameters.deviceId;
                string secretKey = deviceParameters.secretKey;
                return provisionBusinessProvider.GetProvisionDetails(deviceId, secretKey);
            }
            catch(Exception ex)
            {
                throw new System.Exception(ex.Message.ToString());
            }
        }
    }
}
